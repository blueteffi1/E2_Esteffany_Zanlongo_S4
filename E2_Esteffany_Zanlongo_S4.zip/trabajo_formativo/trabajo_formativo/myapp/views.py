from django.shortcuts import render
from django.conf.urls.static import static

# Create your views here.


def index(request):
    return render(request, "index.html")

def registro(request):
    return render(request, 'Registro.html')

def login(request):
    return render(request, 'login.html')

def Accion(request):
    return render(request, 'Accion.html')

def Deporte(request):
    return render(request, 'Deporte-baile.html')

def Disparos(request):
    return render(request, 'Disparos.html')

def Rol(request):
    return render(request, 'Rol-RPG.html')

def Terror(request):
    return render(request, 'Terror.html')