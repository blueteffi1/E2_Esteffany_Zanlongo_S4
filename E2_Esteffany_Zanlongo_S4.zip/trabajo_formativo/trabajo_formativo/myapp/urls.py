from django.urls import path
from .views import index, registro,login, Disparos, Terror, Deporte, Rol, Accion
from django.conf import settings
from django.conf.urls.static import static



urlpatterns = [
    path('', index, name='index'),
    path('HTML/index.html', index, name='index'),
    path('HTML/Registro.html', registro, name='Registro'),
    path('HTML/login.html', login, name='login'),
    path('HTML/Accion.html', Accion, name='Accion'),
    path('HTML/Deporte-baile.html', Deporte, name='Deporte'),
    path('HTML/Disparos.html', Disparos, name='Disparos'),
    path('HTML/Rol-RPG.html', Rol, name='Rol'),
    path('HTML/Terror.html', Terror, name='Terror'),
]



